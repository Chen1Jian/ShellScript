#! /bin/bash

echo "Find kafka topic list"

process=$(docker ps | grep kafka | awk '{print $1}')

kafka_home=$(docker exec -i "$process" /bin/sh -c 'echo $KAFKA_HOME')

echo "Find kafka process is ${process}"


function remove_newline {
    echo $1 | sed 's/[\r\n]//g'
}

kafka_home_f=$(remove_newline $kafka_home)

function topicDescribe {
    echo "=============================$1============================="
    docker exec -i $2 /bin/sh -c "sh $kafka_home_f/bin/kafka-topics.sh --zookeeper 127.0.0.1:2181 --topic $1 --describe"
}

if [[ $1 ]]; then
    topicDescribe "$1" "$process"
else
    topicList=$(docker exec -i "$process" /bin/sh -c "sh $kafka_home_f/bin/kafka-topics.sh --zookeeper 127.0.0.1:2181 --list")
    IFS=$'\n' read -rd '' -a array <<< "$topicList"
    for element in "${array[@]}"
    do
        topic=$(remove_newline $element)
        topicDescribe "$topic" "$process"
    done
fi
