#!/bin/bash

#查es集群状态
if [ "$1" = "cluster" ]
then

  response=$(curl -s -XGET 'http://127.0.0.1:9201/_cat/nodes?v' --header 'Authorization: Basic ZWxhc3RpYzpFbGFzdGljc2VhcmNoQHJ1aWppZQ==')
  echo "$response"
    
  
#查es索引状态
elif [ "$1" = "index" ]
then

  response3=$(curl -s -XGET 'http://127.0.0.1:9201/_cat/indices' --header 'Authorization: Basic ZWxhc3RpYzpFbGFzdGljc2VhcmNoQHJ1aWppZQ==')
  echo "$response3"

else
  
  time=$(date +"%Y-%m-%d_%H:%M:%S")
  container_id=`docker ps | grep elasticsearch | awk '{print $1}'`
  # 获取容器的服务的CPU和内存使用率
  docker_stats_value=$(docker stats --no-stream "$container_id" | tail -n 1)
  cpu_usage=$(echo "$docker_stats_value" | awk '{print $3}')
        
  value_with_unit=$(echo "$docker_stats_value" | awk '{print $4}')
  unit=$(echo "$value_with_unit" | sed 's/[0-9.]//g')  
  # 根据单位进行转换
  if [ "$unit" == "GiB" ]; then
      value_without_unit=$(echo "$value_with_unit" | sed 's/GiB//')
      gib_value=$value_without_unit
  elif [ "$unit" == "MiB" ]; then
      value_without_unit=$(echo "$value_with_unit" | sed 's/MiB//')
      gib_value=$(awk "BEGIN { printf \"%.2f\", $value_without_unit / 1024 }")
  else
      echo "无法识别的单位"
      exit 1
  fi
  # 添加单位
  memory_usage="${gib_value}"
        
        
  PID_value=$(docker inspect "$container_id" | grep \"Pid\" | awk '{print $2}')
  
  echo "elasticsearch-->time:$time,container_id:$container_id,cpu:$cpu_usage,memory:$memory_usage(GiB),PID:$PID_value"
  
fi