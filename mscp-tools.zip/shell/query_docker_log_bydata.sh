#!/bin/bash
#查询docker应用日志（根据日期倒序）
journalctl -r --since $1 --until now  -u docker