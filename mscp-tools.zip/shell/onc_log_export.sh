#!/bin/bash
#一键导出日志到本地onc日志到本地
cd /ibnsdata/rgonc/data/log/
rm -rf /opt/mscp-tools/$(hostname -i)-onc.zip
rm -rf /opt/mscp-tools/$(hostname -i)-onc/
mkdir /opt/mscp-tools/$(hostname -i)-onc/
cp -r  /ibnsdata/rgonc/data/log/karaf.*   /opt/mscp-tools/$(hostname -i)-onc/
zip  -r  log.zip  /opt/mscp-tools/$(hostname -i)-onc/
sz /opt/mscp-tools/$(hostname -i)-onc.zip