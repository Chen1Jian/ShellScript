#!/bin/bash
#查询进程归属哪个容器
docker ps -q | xargs docker inspect --format '{{.Id}}, {{.State.Pid}}, {{.Name}}' |grep $1