#!/bin/bash
#一键查看所有容器状态
docker ps --format "{{.Names}}: {{.Status}}"|awk '{print $2 " " $1}'
