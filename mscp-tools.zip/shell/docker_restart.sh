#!/bin/bash
#重启docker
docker restart $1