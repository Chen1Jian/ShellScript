#!/bin/bash
#清理es数据目录并重启es容器
rm -rf /ibnsdata/elasticsearch/data
docker restart $(docker ps | grep elasticsearch |awk '{print $1}')