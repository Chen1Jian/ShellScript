#!/bin/bash
#一键查看指定微服务容器日志
if [[ "$(docker ps --format "{{.Names}}"|grep $2 | wc -l)" <1  ]]; then
  echo $2"容器不存在,请确认名称是否正确"
elif  [[ "$(docker ps --format "{{.Names}}"|grep $2 | wc -l)" >1  ]]; then
  echo "找到多个名称包含$2的容器，请补齐容器名称，列表如下："
 docker ps --format "{{.Names}}"|grep $2
else
  docker logs --tail $1  $(docker ps | awk '/'$2'/{print $1}')
fi