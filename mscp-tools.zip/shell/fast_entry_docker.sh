#!/bin/bash
#【快速进入容器】
if [[ "$(docker ps --format "{{.Names}}"|grep $1 | wc -l)" <1  ]]; then
  echo $1"容器不存在,请确认名称是否正确"
elif  [[ "$(docker ps --format "{{.Names}}"|grep $1 | wc -l)" >1  ]]; then
  echo "找到多个名称包含$1的容器，请补齐容器名称，列表如下："
 docker ps --format "{{.Names}}"|grep $1
else
  docker exec -it -e LINES=$(tput lines) -e COLUMNS=$(tput cols) $(docker ps | grep $1 |awk '{print $1}') bash
fi
