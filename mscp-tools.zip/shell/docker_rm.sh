#!/bin/bash
#删除docker镜像
docker image rm $1
