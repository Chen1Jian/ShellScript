#!/bin/bash
#【快速查看karaf日志】
tail -f /ibnsdata/rgonc/data/log/karaf.log