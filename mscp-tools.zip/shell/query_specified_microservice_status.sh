#!/bin/bash
#一键查看指定微服务容器状态
if [[ "$(docker ps --format "{{.Names}}"|grep ${1,,} | wc -l)" <1  ]]; then
  echo $1"容器不存在,请确认名称是否正确"
elif  [[ "$(docker ps --format "{{.Names}}"|grep ${1,,} | wc -l)" >1  ]]; then
  echo "找到多个名称包含$1的容器，请补齐容器名称，列表如下："
 docker ps --format "{{.Names}}"|grep ${1,,}
else
  docker ps --format "{{.Names}}: {{.Status}}"|grep ${1,,} |awk '{print $2}'
fi
