#!/bin/bash

kafka_id=$(docker ps | grep kafka | awk '{print $1}')
#echo "$kafka_id"
kafka_home=$(docker exec $kafka_id sh -c 'echo $KAFKA_HOME')

#1、新建topic
create_topic=$(bash /opt/mscp-tools/shell/kafka_safety_topic.sh create hello99 1 1)
echo "$create_topic"

#1.2等待一段时间以确保topic创建成功被识别到
sleep 2

docker exec -i $kafka_id kafka-topics.sh --zookeeper 127.0.0.1:2181 --topic hello99 --describe > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "Failed Kafka does not exist. Exiting..."
  exit 1
fi

#2、发送消息
#echo "Sending message..."
timeout 15s docker exec -i $kafka_id kafka-console-producer.sh --producer.config "$kafka_home"/config/producer.properties --broker-list localhost:9093 --topic hello99 << EOF
This is a test message
EOF

#2.1、检查发送消息是否成功
if [ $? -ne 0 ]; then
  echo "Failed to send message. Exiting..."
  exit 1
fi

#2.2等待一段时间以确保消息被处理
sleep 2

#3、接收消息
#echo "Receiving message..."
docker exec -i $kafka_id kafka-console-consumer.sh --consumer.config "$kafka_home"/config/consumer.properties --bootstrap-server localhost:9093 --topic hello99 --from-beginning --max-messages 1

#3.1、检查接收消息是否成功
if [ $? -ne 0 ]; then
  echo "Failed to receive message. Exiting..."
  exit 1
fi

#4、删除topic
delete_topic=$(bash /opt/mscp-tools/shell/kafka_safety_topic.sh delete hello99)
echo "$delete_topic"