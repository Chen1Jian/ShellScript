#! /bin/bash
change_config() {
  echo "change config active=$1"
  active=$1
  curl --location --request PUT 'http://localhost:18000/api/v1/deployment/configmap/part/update' \
  --header 'Content-Type: application/json' \
  --data '{
      "name": "kafka-run-config",
      "data": {
          "active": "'"${active}"'"
      }
  }'
}


restart_kafka() {
    response=$(curl --location --request GET 'http://localhost:18000/api/v1/node/withResource')
    count=$(echo "$response" | grep -o '"id"' | wc -l)
    if [ "$count" -gt 1 ]; then
        echo "restart all kafka"
        for i in {1..3}
        do
          echo restart kafka-$i
          curl --location --request POST 'http://localhost:18000/api/v1/deployment/app/restart' \
          --header 'Content-Type: application/json' \
          --data '{
          "name" : "'"kafka-${i}"'"
          }'
        done
    else
        echo "restart kafka-1"
        curl --location --request POST 'http://localhost:18000/api/v1/deployment/app/restart' \
          --header 'Content-Type: application/json' \
          --data '{
          "name" : "kafka-1"
          }'
    fi
}


change_config $1
restart_kafka $1
