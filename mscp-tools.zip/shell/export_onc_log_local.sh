#!/bin/bash
#一键导出日志到本地onc日志到本地
s=$(hostname -i)-$(date +%s)
rm -rf /opt/mscp-tools/onc/
mkdir /opt/mscp-tools/onc/
cp -r  /ibnsdata/rgonc/data/log/karaf.*   /opt/mscp-tools/onc/
zip  -r  /opt/mscp-tools/onc/$s.zip  /opt/mscp-tools/onc/
sz -e /opt/mscp-tools/onc/$s.zip