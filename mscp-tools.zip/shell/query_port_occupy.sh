#!/bin/bash
#查询端口占用情况
netstat -anp | grep $1
