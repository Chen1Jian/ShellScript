#!/bin/bash
#关闭docker
docker stop $1