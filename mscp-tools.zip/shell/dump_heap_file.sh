#!/bin/bash
#dump某个服务堆文件
if [[ "$(docker ps | grep ${1,,})" = "" ]]; then
	echo $1"容器不存在,请重新输入"
else
  s=$(hostname -i)-$(date +%s)
  docker exec -i `docker ps | grep ${1,,} | awk '{print $1}'` jmap -dump:file=$s 1
  docker cp `docker ps | grep ${1,,} | awk '{print $1}'`:/home/jhipster/$s /home/dump
fi