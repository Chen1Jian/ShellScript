#!/bin/bash
#删除防火墙端口白名单
firewall-cmd --zone=public --remove-port="$1"/tcp --permanent
firewall-cmd --reload