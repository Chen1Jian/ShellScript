#!/bin/sh

check() {
    if (( $# < 2)); then
        echo "参数个数有误。usage: app.jar fuzzy_container_name {all}
        all: 替换集群所有节点"
        exit 1
    elif (( $# == 2 ));then
        echo ""
    else
        if [ "$3" != 'all' ]; then
            echo "usage: app.jar fuzzy_container_name {all}
                    all: 替换集群所有节点"
            exit 1
        fi
    fi
    image_id=(`docker ps | grep ${1,,} | awk '{print $1}'`)
    found_image=${#image_id[*]}
    if (( $found_image > 1))
    then
        echo "找到不止一个镜像，请指定一个镜像"
        echo "${image_id[@]}"
        exit 1
    fi
    # 检测jar包
    if [ ! -e "$2" ]; then
        echo "$2文件不存在"
        exit 1
    fi
}

run() {
    # 定义主机列表,
    if [[ $3 == 'all' ]]; then
        hosts=('rgibns1' 'rgibns2' 'rgibns3')
    else
        hosts=$(hostname)
    fi
    if [ ${#hosts[*]} == 1 ]; then
        echo "替换本地镜像"
        chmod +x "$2"
        docker cp $2 `(docker ps | grep ${1,,} | awk '{print $1}')`:/home/jhipster/app.jar
        echo "重启容器"
        docker restart `(docker ps | grep ${1,,} | awk '{print $1}')`
        echo "替换完成"
        exit 0
    fi
	destination_ip=('rgibns1' 'rgibns2' 'rgibns3')
	if ping -c1 $destination_ip &>/dev/null
	then 
	for remote in ${hosts[*]}; do
echo "替换$remote节点服务!"
        echo "拷贝jar包到其他节点"
        cmd="mkdir -p /opt/mscp-tools/temp/"
        ssh root@$remote $cmd
        scp $2 root@"$remote":/opt/mscp-tools/temp/
        echo "替换镜像"
        cmd="chmod +x /opt/mscp-tools/temp/${2##*/} && docker cp /opt/mscp-tools/temp/${2##*/} \`(docker ps | grep ${1,,} | awk '{print \$1}')\`:/home/jhipster/app.jar"
        echo "重启容器"
        ssh root@$remote $cmd
        cmd="docker restart \`(docker ps | grep ${1,,} | awk '{print \$1}')\` && exit"
       # echo $cmd
        ssh root@"$remote" "$cmd"
    done
    echo "替换完成"
	else
	echo "1"
	fi
}

main() {
    check "$@"
    run "$@"
}

main "$@"