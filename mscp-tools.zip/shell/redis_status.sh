#!/bin/bash

#redis的容器id
redis_container=$(docker ps | grep redis- | awk '{print $1}')

# 检查 Redis 增删改查功能是否正常
if [ "$1" = "crud" ]
then
  
  #新增操作
  insert_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie SET key value)
  #查询操作
  query_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie GET key)
  #修改操作
  update_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie SET key value1)
  #删除操作
  delete_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie DEL key)
  
  # 输出结果
  echo ""
  echo "SET key value验证新增功能："
  echo "$insert_result"
  echo ""
  echo "GET key验证查询功能："
  echo "$query_result"
  echo ""
  echo "SET key value1验证修改功能："
  echo "$update_result"
  echo ""
  echo "DEL key验证删除功能："
  echo "$delete_result"
  
#获取主节点信息
elif [ "$1" = "master" ]
then

  # 执行 Redis 命令并获取主节点信息，输出结果
  result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 18379 -a redis_ruijie SENTINEL get-master-addr-by-name mscp_sentinel)

  # 输出结果
  # 检查输出结果是否为空
  if [[ -z $result || $result =~ "Connection refused" ]]; then
    echo "当前环境为非集群环境或连接集群异常！"
    echo "$result"
  else
    echo "redis status--主节点信息如下："
    echo "$result"
  fi
  
#获取集群信息
elif [ "$1" = "cluster" ]
then

  # 执行 Redis 命令并获取集群信息，输出结果
  result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 18379 -a redis_ruijie SENTINEL masters)

  # 输出结果
  # 检查输出结果是否为空
  if [[ -z $result || $result =~ "Connection refused" ]]; then
    echo "当前环境为非集群环境或连接集群异常！"
    echo "$result"
  else
    echo "redis status--集群信息如下："
    echo "$result"
  fi
  
else
    echo "Unrecognized parameter $1."
fi
































