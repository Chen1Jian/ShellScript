#! /bin/bash

echo "Find kafka group list"

process=$(docker ps | grep kafka | awk '{print $1}')

kafka_home=$(docker exec -i "$process" /bin/sh -c 'echo $KAFKA_HOME')

echo "Find kafka process is ${process}"


function remove_newline {
    echo $1 | sed 's/[\r\n]//g'
}

kafka_home_f=$(remove_newline $kafka_home)

function groupDescribe {
    echo "=============================$1============================="
    docker exec -i $2 /bin/sh -c "sh $kafka_home_f/bin/kafka-consumer-groups.sh --describe --bootstrap-server 127.0.0.1:9092 --group $1"
}

if [[ $1 ]]; then
    groupDescribe "$1" "$process"
else
    groupList=$(docker exec -i "$process" /bin/sh -c "sh $kafka_home_f/bin/kafka-consumer-groups.sh --bootstrap-server 127.0.0.1:9092 --list")

    IFS=$'\n' read -rd '' -a array <<< "$groupList"
    for element in "${array[@]}"
    do
        group=$(remove_newline $element)
        groupDescribe ${group} ${process}
    done
fi





