#!/bin/bash

port=""
url=""

#获取uaa的token
if [ "$1" = "uaa" ]
then

  port="9999"
  url="http://127.0.0.1:$port/oauth/token"
  
#获取api-gateway的token  
elif [ "$1" = "gate" ]
then

  port="18181"  
  url="http://127.0.0.1:$port/auth/token"
  
#获取haproxy的token  
elif [ "$1" = "haproxy" ]
then
  
  port="18080"
  url="http://127.0.0.1:$port/auth/token"
  
fi


response=$(curl -s --location --request POST "$url" --header 'Content-Type: application/x-www-form-urlencoded' --header 'Authorization: Basic d2ViX2FwcDpyZ3Nkbg==' --data-urlencode 'grant_type=password' --data-urlencode "username=$2" --data-urlencode "password=$3")
  formatted_response=$(echo "$response" | jq '.')
  
echo "$formatted_response"
