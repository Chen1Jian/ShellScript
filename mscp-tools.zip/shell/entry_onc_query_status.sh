#!/bin/bash
#【快速进入onc容器并查看onc启动情况】
if  [[ "$(docker ps --format "{{.Names}}"|grep rgonc-base | wc -l)" >1  ]]; then
  echo "找到多个名称包含rgonc-base的容器，请补齐容器名称，列表如下："
  docker ps --format "{{.Names}}"|grep rgonc-base
else
  docker exec -it `docker ps | grep rgonc-base | awk '{print $1}'` ./bin/client -u ruijie
fi