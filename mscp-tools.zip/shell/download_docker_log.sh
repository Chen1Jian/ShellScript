#!/bin/bash
#【快速下载容器日志】
if [[ "$(docker ps --format "{{.Names}}"|grep $1 | wc -l)" <1  ]]; then
  echo $1"容器不存在,请确认名称是否正确"
elif  [[ "$(docker ps --format "{{.Names}}"|grep $1 | wc -l)" >1  ]]; then
  echo $1"找到多个名称包含$1的容器，请补齐容器名称，列表如下："
 docker ps --format "{{.Names}}"|grep $1
else
  rm -rf /opt/mscp-tools/$1.log
  docker logs $(docker ps | grep $1 |awk '{print $1}') > /opt/mscp-tools/$1.log
  sz /opt/mscp-tools/$1.log
fi