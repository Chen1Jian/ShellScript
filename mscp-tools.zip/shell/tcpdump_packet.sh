#!/bin/bash
#抓大流量包
tcpdump -i any -w /opt/mscp-tools/tcpdump.pcaps