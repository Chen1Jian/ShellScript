#!/bin/bash
#查询zookeeper集群状态
docker exec  -i `docker ps | grep _zookeeper | awk '{print $1}'`  zkServer.sh status
