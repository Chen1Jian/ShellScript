#!/bin/bash
#添加防火墙端口白名单
firewall-cmd --zone=public --add-port="$1"/tcp --permanent
firewall-cmd --reload
