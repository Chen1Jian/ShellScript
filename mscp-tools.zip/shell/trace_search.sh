#!/bin/bash

hosts=('rgibns1' 'rgibns2' 'rgibns3')
destination_ip=('rgibns1' 'rgibns2' 'rgibns3')
archive_logs_dir="/var/log/ibnslogs"
default_components="all"
default_time="all"

#opts=$(getopt -o s: --long search: -n 'trace_search.sh' -- "$@")
#eval set -- "$opts"
#
#while true; do
#  case "$1" in
#    -s|--search)
#      trace_id=$2
#      shift 2
#      ;;
#    --)
#      shift
#      break
#      ;;
#    *)
#      echo "illegal param options: $1"
#      exit 1
#      ;;
#  esac
#done

# fix_me:支持时间范围、指定组件

trace_id=$1
components=$2
time=$3

#设置默认参数
components=${components:-$default_components}
time=${time:-$default_time}

response=$(curl --location --request GET 'http://localhost:18000/api/v1/node')
node=$(echo "$response" | grep -o '"id"' | wc -l)

if [[ -z $trace_id ]]; then
  echo "param -s|--search not provided"
  exit 1
fi

if [[ $node == "3" ]]; then
    hosts=('rgibns1' 'rgibns2' 'rgibns3')
else
    hosts=$(hostname)
fi

echo "search: $trace_id"
echo "components: $components"
echo "time: $time"
echo "node: $node"

if [[ $node != 1 && $node != 3 ]]; then
  echo "Error: Invalid node value. Expected 1 or 3."
  exit 1
fi

date_pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}$"
date_range_pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}~[0-9]{4}-[0-9]{2}-[0-9]{2}$"

if [[ $time != "all" && ! $time =~ $date_pattern && ! $time =~ $date_range_pattern ]]; then
  echo "Error: Invalid time format. Expected format: 'YYYY-MM-DD~YYYY-MM-DD', 'YYYY-MM-DD' or 'all'."
  exit 1
fi

if [[ $time =~ $date_range_pattern ]]; then
  start=$(echo "$time" | awk -F '~' '{print $1}')
  end=$(echo "$time" | awk -F '~' '{print $2}')
  if [[ $end < $start ]]; then
    echo "Error: Illegal date range, end date is earlier than start date."
    exit 1;
  fi
  # 时间范围导出
  start=$(echo "$time" | awk -F '~' '{print $1}')
  end=$(echo "$time" | awk -F '~' '{print $2}')
  # 将日期转换为时间戳
  start_timestamp=$(date -d "$start" "+%s")
  end_timestamp=$(date -d "$end" "+%s")
  # 列出时间范围内的所有日期
  current_timestamp=$start_timestamp
  while [[ $current_timestamp -le $end_timestamp ]]
  do
    current_date=$(date -d "@$current_timestamp" "+%Y-%m-%d")
    dates+=("$current_date")  # 将日期添加到数组中
    current_timestamp=$((current_timestamp + 86400)) # 增加一天的时间戳（86400秒）
  done
  date_str=$(IFS=','; echo "${dates[*]}")
  echo "date: $date_str"  # 打印日期数组
fi


search_trace_info() {
    local dir=$1
    local remote=$2
    local trace_id=$3
    local components=$4
    local dates=$5
    compressed_extensions=("zip" "tar" "gz" "rar")
    is_compressed=false
    for entry in "$dir"/*; do
        if [[ -d "$entry" ]]; then
            if [ "$components" != "all" ]; then
              IFS=' ' read -ra component_array <<< "$components"
              for component in "${component_array[@]}"; do
                if [[ "$entry" == *"$component"* ]]; then
                    output=$(echo "$entry" | grep "$component")
                    if [ -n "$output" ]; then
                       # 是指定的组件 继续递归
                       search_trace_info "$entry" "$remote" "$trace_id" "$components" "$date_str"
                    fi
                fi
              done
            else
              search_trace_info "$entry" "$remote" "$trace_id" "$components" "$date_str"
            fi
        elif [[ -f "$entry" ]]; then
            # 文件检索调用链信息
            if [ -z "$remote" ]; then
                remote="local"
            fi
            # 判断是否压缩
            for ext in "${compressed_extensions[@]}"; do
              if [[ "$entry" == *"$ext"* ]]; then
                is_compressed=true
                break
              fi
            done
            if [[ -z "$date_str" ]]; then
                if [ "$time" != "all" ]; then
                    if [[ "$entry" == *"$time"* ]] && ! $is_compressed; then
                        filtered_result=$(cat "$entry" | grep "$trace_id")
                        if [[ -n "$filtered_result" ]]; then
                            tag="$remote $entry"
                            modified_result=$(echo "$filtered_result" | sed -E "s#([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3})#$tag \1#")
                            echo "$modified_result"
                        fi
                    fi
                else
                    # 全部日期的文件查找
                    if echo "$entry" | grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}' && ! $is_compressed; then
                        filtered_result=$(cat "$entry" | grep "$trace_id")
                        if [[ -n "$filtered_result" ]]; then
                            tag="$remote $entry"
                            modified_result=$(echo "$filtered_result" | sed -E "s#([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3})#$tag \1#")
                            echo "$modified_result"
                        fi
                    fi
                fi

            else
                IFS=',' read -ra dates <<< "$date_str"
                for date in "${dates[@]}"; do
                  output=$(echo "$entry" | grep "$date")
                  if [ -n "$output" ] && [ "$is_compressed" = false ]; then
                     filtered_result=$(cat "$entry" | grep "$trace_id")
                     echo $filtered_result
                     if [ -n "$filtered_result" ]; then
                         tag="$remote $entry"
                         modified_result=$(echo "$filtered_result" | sed -E "s#([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3})#$tag \1#")
                         echo "$modified_result"
                     fi
                  fi
                done
            fi
        fi
    done
}


main() {
    if [ $node == 3 ]; then
        if ping -c1 $destination_ip &>/dev/null
        then
          for remote in ${hosts[*]}; do
              echo "remote host $remote search $trace_id"
              ssh -t root@$remote "$(declare -f search_trace_info); search_trace_info \"$archive_logs_dir\" \"$remote\" \"$trace_id\" \"$components\" \"$date_str\"exit" >> $archive_logs_dir/traceInfo.txt
          done
        fi
    else
        hosts=$(hostname)
        echo "local host search $trace_id"
        search_trace_info  "$archive_logs_dir" "$remote" "$trace_id" "$components" "$dates" >> $archive_logs_dir/traceInfo.txt
    fi
    if [ -f "$archive_logs_dir/traceInfo.txt" ]; then
       cat $archive_logs_dir/traceInfo.txt | sort -k2.1,2.23
       rm -rf $archive_logs_dir/traceInfo.txt
    fi
}

main
