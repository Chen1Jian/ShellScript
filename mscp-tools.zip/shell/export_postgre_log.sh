#!/bin/bash
#导出postgreSQL容器日志
docker logs `docker ps | grep postgres_ | awk '{print $1}'` > /opt/mscp-tools/pg.log 2>&1