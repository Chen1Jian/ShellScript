#!/bin/bash
#添加docker证书
rm -rf /etc/docker/certs.d/registry.mig.ruijie.net/
rm -rf /etc/docker/certs.d/harbor.mig.ruijie.net/
mkdir -p /etc/docker/certs.d/registry.mig.ruijie.net/
mkdir -p /etc/docker/certs.d/harbor.mig.ruijie.net/
cp -r /opt/mscp-tools/file/registry.mig.ruijie.net.crt /etc/docker/certs.d/registry.mig.ruijie.net/
cp -r /opt/mscp-tools/file/harbor.mig.ruijie.net.crt /etc/docker/certs.d/harbor.mig.ruijie.net/