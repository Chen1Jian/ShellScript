#!/bin/bash

# 默认值
hosts=('rgibns1' 'rgibns2' 'rgibns3')
destination_ip=('rgibns1' 'rgibns2' 'rgibns3')
default_ips="current"
default_components="all"
default_time="all"
valid_ips=("current" "rgibns1" "rgibns2" "rgibns3")

root_user="root"

#opts=$(getopt -o i:c:t: --long ips:,components:,time: -n 'export_logs.sh' -- "$@")
#eval set -- "$opts"
#
# 解析选项参数
#while true; do
#  case "$1" in
#    -i|--ips)
#      ips=$2
#      shift 2
#      ;;
#    -c|--components)
#      components=$2
#      shift 2
#      ;;
#    -t|--time)
#      time=$2
#      shift 2
#      ;;
#    --)
#      shift
#      break
#      ;;
#    *)
#      echo "illegal param options: $1"
#      exit 1
#      ;;
#  esac
#done

ips=$1
components=$2
time=$3

# 获取参数
ips=${ips:-$default_ips}
components=${components:-$default_components}
time=${time:-$default_time}


echo "ips: $ips"
echo "components: $components"
echo "time: $time"

found=false
for valid_ip in "${valid_ips[@]}"; do
    if [ "$valid_ip" = "$ips" ]; then
        found=true
        break
    fi
done

if [ "$found" = false ]; then
    echo "Error: Invalid node name '${ip}', valid is in (current rgibns1 rgibns2 rgibns3)"
    exit 1
fi


#for ip in "${ips[@]}"; do
#  if [[ ! " ${valid_ips[@]} " =~ " ${ip} " ]]; then
#    echo "Error: Invalid node name '${ip}', valid are (current rgibns1 rgibns2 rgibns3)"
#    exit 1
#  fi
#done


date_pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}$"
date_range_pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}~[0-9]{4}-[0-9]{2}-[0-9]{2}$"

if [[ $time != "all" && ! $time =~ $date_pattern && ! $time =~ $date_range_pattern ]]; then
  echo "Error: Invalid time format. Expected format: 'YYYY-MM-DD~YYYY-MM-DD', 'YYYY-MM-DD' or 'all'."
  exit 1
fi

if [[ $time =~ $date_range_pattern ]]; then
  start=$(echo "$time" | awk -F '~' '{print $1}')
  end=$(echo "$time" | awk -F '~' '{print $2}')
  if [[ $end < $start ]]; then
    echo "Error: Illegal date range, end date is earlier than start date."
    exit 1;
  fi
fi


fetch_log() {
    export_logs_dir="/tmp/export/logs"
    archive_logs_dir="/var/log/ibnslogs"
    export_logs_tmp_dir="/tmp/export/tmp"
    export_log_tar_prefix="export_log.tar.gz"
    date_range_pattern="^[0-9]{4}-[0-9]{2}-[0-9]{2}~[0-9]{4}-[0-9]{2}-[0-9]{2}$"
    local ip=$1
    local components=$2
    local ips=$3
    local time=$4
    local current_ip=$5

    if [[ $time =~ $date_range_pattern ]]; then
      start=$(echo "$time" | awk -F '~' '{print $1}')
      end=$(echo "$time" | awk -F '~' '{print $2}')
    fi

    cd $archive_logs_dir;
    if [ "$components" != "all" ]; then
      for component in *; do
        # 检查元素是否在 components 中
        if [[ " $components " =~ " $component " ]]; then
#          echo "export component $component"
          mkdir -p $export_logs_tmp_dir/$component
          chmod 666 $export_logs_tmp_dir/$component
          local matched_files=$(ls "$archive_logs_dir/$component/" | grep -E '[0-9]{4}-[0-9]{2}-[0-9]{2}')

          if [[ -z $matched_files ]]; then
#            echo "copy all components logs"
            # 如果不存在匹配的文件，将服务全部文件复制到导出目录
            cp -R $archive_logs_dir/$component/* $export_logs_tmp_dir/$component/
          else
#            echo "copy component $component logs"
            # 存在匹配的复制指定日期的到导出目录
            if [ -n "$(ls -A "$archive_logs_dir/$component")" ]; then
               if [ "$time" != "all" ] && [ -n "$(ls -A $archive_logs_dir/$component)" ]; then
                   if [[ $time =~ $date_range_pattern ]]; then
                     # 时间范围导出
                     start=$(echo "$time" | awk -F '~' '{print $1}')
                     end=$(echo "$time" | awk -F '~' '{print $2}')
                     # 将日期转换为时间戳
                     start_timestamp=$(date -d "$start" "+%s")
                     end_timestamp=$(date -d "$end" "+%s")
                     # 列出时间范围内的所有日期
                     current_timestamp=$start_timestamp
                     while [[ $current_timestamp -le $end_timestamp ]]
                     do
                       current_date=$(date -d "@$current_timestamp" "+%Y-%m-%d")
                       for file in "$archive_logs_dir/$component"/*"$current_date"*
                       do
                         if [ -f "$file" ]; then
                           cp -R "$file" "$export_logs_tmp_dir/$component/"
                         fi
                       done
                       current_timestamp=$((current_timestamp + 86400)) # 增加一天的时间戳（86400秒）
                     done
                   else
                       # 时间点导出
                       for file in "$archive_logs_dir/$component"/*"$time"*
                       do
                         if [ -f "$file" ]; then
                           cp -R "$file" "$export_logs_tmp_dir/$component/"
                         fi
                       done
                   fi
               else
                   if [ -n "$(ls -A "$archive_logs_dir/$component")" ]; then
                      # 组件归档目录不为空获取全部时间的日志
#                      echo "get all date logs"
                      cp -R "$archive_logs_dir/$component"/* "$export_logs_tmp_dir/$component"
                   fi
               fi
            fi
          fi
        fi
      done
    else
#      echo "export all components logs"
      for component in *; do
        mkdir -p $export_logs_tmp_dir/$component
        chmod 666 $export_logs_tmp_dir/$component
        local matched_files=$(ls "$archive_logs_dir/$component/" | grep -E '[0-9]{4}-[0-9]{2}-[0-9]{2}')

        if [[ -z $matched_files ]]; then
#          echo "copy all components logs"
          # 如果不存在匹配的文件，将服务全部文件复制到导出目录
          cp -R $archive_logs_dir/$component/* $export_logs_tmp_dir/$component/
        else
#          echo "copy component $component logs"
          # 存在匹配的复制指定日期的到导出目录
          if [ -n "$(ls -A "$archive_logs_dir/$component")" ]; then
             if [ "$time" != "all" ]  && [ -n "$(ls -A $archive_logs_dir/$component)" ]; then
                 if [[ $time =~ $date_range_pattern ]]; then
                   start=$(echo "$time" | awk -F '~' '{print $1}')
                   end=$(echo "$time" | awk -F '~' '{print $2}')
                   # 将日期转换为时间戳
                   start_timestamp=$(date -d "$start" "+%s")
                   end_timestamp=$(date -d "$end" "+%s")
                   # 列出时间范围内的所有日期
                   current_timestamp=$start_timestamp
                   while [[ $current_timestamp -le $end_timestamp ]]
                   do
                     current_date=$(date -d "@$current_timestamp" "+%Y-%m-%d")
                     for file in "$archive_logs_dir/$component"/*"$current_date"*
                     do
                       if [ -f "$file" ]; then
                         cp -R "$file" "$export_logs_tmp_dir/$component/"
                       fi
                     done
                     current_timestamp=$((current_timestamp + 86400)) # 增加一天的时间戳（86400秒）
                   done
                 else
                   for file in "$archive_logs_dir/$component"/*"$time"*
                   do
                     if [ -f "$file" ]; then
                       cp -R "$file" "$export_logs_tmp_dir/$component/"
                     fi
                   done
                 fi
             else
                 if [ -n "$(ls -A "$archive_logs_dir/$component")" ]; then
                    # 获取全部时间的日志
#                    echo "get all date logs"
                    cp -R "$archive_logs_dir/$component"/* "$export_logs_tmp_dir/$component"
                 fi
             fi
          fi
        fi
      done
    fi
    # 执行压缩
    # 不存在需要创建归档路径
    if [ ! -d "$export_logs_dir" ]; then
      mkdir -p "$export_logs_dir"
      chmod 666 $export_logs_dir
    fi
    # 检查目录是否存在
    if [ -d "$export_logs_tmp_dir" ]; then
      # 压缩目录
      tar -czvf "$export_log_tar_prefix" -C "$export_logs_tmp_dir" .
      # 复制到指定目录
      cp -R "$export_log_tar_prefix" "$export_logs_dir"
      echo "log export success, path: $export_logs_dir/$export_log_tar_prefix"
      # 删除目录
      rm -rf "$export_logs_tmp_dir"
      # 删除压缩文件
      rm -rf "$archive_logs_dir/$export_log_tar_prefix"
    fi
}

main() {
   if [ "$ips" != "current" ]; then
       if ping -c1 $destination_ip &>/dev/null
       then
       	   for remote in ${ips[*]}; do
              echo "ssh to $ip"
              ssh -t $root_user@$remote "$(declare -f fetch_log); fetch_log \"$remote\" \"$components\" \"$ips\" \"$time\" \"$(hostname)\""
       	   done
       fi
   else
     fetch_log "$(hostname)" "$components" "$ips" "$time" "$(hostname)"
   fi
}

main
