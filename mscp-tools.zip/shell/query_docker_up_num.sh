#!/bin/bash
#一键查看Up状态的容器数量（用于快速确认服务器上容器启动是否正常）
docker ps --format "{{.Names}}: {{.Status}}"|grep Up | wc -l