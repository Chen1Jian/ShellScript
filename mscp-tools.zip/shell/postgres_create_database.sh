#!/bin/bash
#创建测试用数据库
image_id=$(docker ps | grep postgres_ | awk '{print $1}')
docker exec -e PGPASSWORD=rJ1#sDn@ -i $image_id psql mscp_uaa --username "postgresadmin" -h 127.0.0.1 -p 25432 -tAc "CREATE USER $1 WITH PASSWORD '$1'"
docker exec -e PGPASSWORD=rJ1#sDn@ -i $image_id psql mscp_uaa --username "postgresadmin" -h 127.0.0.1 -p 25432 -tAc "CREATE DATABASE $1"
docker exec -e PGPASSWORD=rJ1#sDn@ -i $image_id psql mscp_uaa --username "postgresadmin" -h 127.0.0.1 -p 25432 -tAc "GRANT ALL PRIVILEGES ON DATABASE $1 TO $1"