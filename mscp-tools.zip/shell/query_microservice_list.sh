#!/bin/bash
#查询微服务列表
curl --location --request GET 'http://127.0.0.1:8500/v1/agent/checks' \
--header 'X-Consul-Token: rJ1#sDn' | python -m json.tool