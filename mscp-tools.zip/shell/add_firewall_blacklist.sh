#!/bin/bash
#添加防火墙IP黑名单
firewall-cmd --add-rich-rule="rule family="ipv4" source address="$1" reject"