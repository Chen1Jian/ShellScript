#!/bin/bash
#添加防火墙IP白名单
firewall-cmd --remove-rich-rule="rule family="ipv4" source address="$1" reject"
firewall-cmd --add-rich-rule="rule family="ipv4" source address="$1" accept"
firewall-cmd --runtime-to-permanent