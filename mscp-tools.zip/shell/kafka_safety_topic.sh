#!/bin/bash

#获取 Kafka 容器的 ID
container_id=$(docker ps | grep kafka | awk '{print $1}')

#查看所有topic
if [ "$1" = "list" ]
then

docker exec -i $container_id /bin/bash -c '
    # 步骤 3: 获取环境变量地址
    kafka_home=$KAFKA_HOME

    # 步骤 4: 拼接路径
    kafka_bin=$kafka_home/bin

    # 步骤 5: 切换到路径
    cd $kafka_bin

    # 步骤 6: 执行命令
    result=$(sh kafka-topics.sh --zookeeper 127.0.0.1:2181 --list)

    # 步骤 7: 输出执行结果
    echo "查询结果: $result"
'


#创建topic
elif [ "$1" = "create" ]
then
  
topic_name=$2
replication_num=$3
partitions_num=$4
  
docker exec -i $container_id /bin/bash -c '
    # 步骤 3: 获取环境变量地址
    kafka_home=$KAFKA_HOME

    # 步骤 4: 拼接路径
    kafka_bin=$kafka_home/bin

    # 步骤 5: 切换到路径
    cd $kafka_bin

    # 步骤 6: 执行命令
    result=$(sh kafka-topics.sh --zookeeper  127.0.0.1:2181 --replication-factor '"$replication_num"' --partitions '"$partitions_num"' --topic '"$topic_name"' --create)

    # 步骤 7: 输出执行结果
    echo "创建结果: $result"
'

#删除topic
elif [ "$1" = "delete" ]
then

topic_name=$2
  
docker exec -i $container_id /bin/bash -c '
    # 步骤 3: 获取环境变量地址
    kafka_home=$KAFKA_HOME

    # 步骤 4: 拼接路径
    kafka_bin=$kafka_home/bin

    # 步骤 5: 切换到路径
    cd $kafka_bin

    # 步骤 6: 执行命令
    result=$(sh kafka-topics.sh --zookeeper  127.0.0.1:2181 --delete --topic '"$topic_name"')

    # 步骤 7: 输出执行结果
    echo "删除结果: $result"
'

#查看topic状态
elif [ "$1" = "status" ]
then

topic_name=$2
  
docker exec -i $container_id /bin/bash -c '
    # 步骤 3: 获取环境变量地址
    kafka_home=$KAFKA_HOME

    # 步骤 4: 拼接路径
    kafka_bin=$kafka_home/bin

    # 步骤 5: 切换到路径
    cd $kafka_bin

    # 步骤 6: 执行命令
    result=$(sh kafka-topics.sh --zookeeper 127.0.0.1:2181 --topic '"$topic_name"' --describe)

    # 步骤 7: 输出执行结果
    echo "状态信息: $result"
'

#查看所有topic
elif [ "$1" = "g-list" ]
then

docker exec -i $container_id /bin/bash -c '
    # 步骤 3: 获取环境变量地址
    kafka_home=$KAFKA_HOME

    # 步骤 4: 拼接路径
    kafka_bin=$kafka_home/bin

    # 步骤 5: 切换到路径
    cd $kafka_bin

    # 步骤 6: 执行命令
    result=$(sh kafka-consumer-groups.sh --command-config $KAFKA_HOME/config/consumer.properties --bootstrap-server 127.0.0.1:9093 --list)

    # 步骤 7: 输出执行结果
    echo "查询结果: $result"
'

#查看某个group的消费情况
elif [ "$1" = "g-status" ]
then

group_name=$2

docker exec -i $container_id /bin/bash -c '
    # 步骤 3: 获取环境变量地址
    kafka_home=$KAFKA_HOME

    # 步骤 4: 拼接路径
    kafka_bin=$kafka_home/bin

    # 步骤 5: 切换到路径
    cd $kafka_bin

    # 步骤 6: 执行命令
    result=$(kafka-consumer-groups.sh --describe --command-config $KAFKA_HOME/config/consumer.properties --bootstrap-server 127.0.0.1:9093 --group '"$group_name"')

    # 步骤 7: 输出执行结果
    echo "查询结果: $result"
'

fi