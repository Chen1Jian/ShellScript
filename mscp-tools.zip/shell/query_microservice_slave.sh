#!/bin/bash
#查询微服务主从
curl -s --user admin:admin 'http://127.0.0.1:8761/eureka/apps/'${1,,} | grep -C20 "<isLeader>1</isLeader>"
