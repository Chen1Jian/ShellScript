#! /bin/bash
change_config() {
  echo "Open 2281 port for zookeeper."
  if [[ $1 ]]; then
    hosts=($(cat /etc/hosts | grep rgibns | awk '{print $1}'))
    for remote in "${hosts[@]}"; do
        cmd="echo clientPort=2281 >> /ibnsdata/mscp/zookeeper/conf/zoo.cfg"
        ssh root@$remote $cmd
    done
  else
   echo clientPort=2281 >> /ibnsdata/mscp/zookeeper/conf/zoo.cfg
  fi
}

restart_zookeeper() {
  echo "Restarting zookeeper..."
  if [[ $1 ]]; then
    for i in {1..3}
    do 
      echo restart zookeeper-$i
      curl --location --request POST 'http://127.0.0.1:18000/api/v1/deployment/app/restart' \
      --header 'Content-Type: application/json' \
      --data '{
      "name" : "'"zookeeper-${i}"'"
      }'
    done
  else
    curl --location --request POST 'http://127.0.0.1:18000/api/v1/deployment/app/restart' \
      --header 'Content-Type: application/json' \
      --data '{
      "name" : "zookeeper-1"
      }'
  fi
}

change_config $1
restart_zookeeper $1
