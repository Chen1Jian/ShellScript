#!/bin/bash

echo "一键检查系统健康"

system_status=""
sentinel_status=$(docker ps | grep sentinel)
insert_result=""
query_result=""
update_result=""
delete_result=""
ip=""
port=""
output1_1=
output1_2=
output1_3=
output2_1=
output2_2=
output3_1=
output3_2=
output3_3=
output4_1=
output4_2=
output4_3=
output5_1=
output6_1=
output7_1=

outinfo1_1=
outinfo1_2=
outinfo1_3=
outinfo2_1=
outinfo2_2=
outinfo3_1=
outinfo3_2=
outinfo3_3=
outinfo4_1=
outinfo4_2=
outinfo4_3=
outinfo5_1=
outinfo6_1=
outinfo7_1=


if [ -n "$sentinel_status" ]; then
  system_status="cluster"
else
  system_status="alone"
fi


if [ "$system_status" == "alone" ]
then
  
  echo "识别到当前为单机环境,开始检查系统健康："

elif [ "$system_status" == "cluster" ]
then
  
  echo "识别到当前为集群环境,开始检查系统健康："
  
fi
echo "===========================================1、查磁盘==========================================="
echo "********************1.1文件系统磁盘大小********************"
resutl1_1=$(bash /opt/mscp-tools/shell/disk_size.sh system)
echo "$resutl1_1"
echo "***************1.2查看/ibnsdata文件夹磁盘大小***************"
resutl1_2=$(bash /opt/mscp-tools/shell/disk_size.sh ibns)
echo $resutl1_2
echo "************1.3查看/var/lib/docker文件夹磁盘大小************"
resutl1_3=$(bash /opt/mscp-tools/shell/disk_size.sh docker)
echo $resutl1_3
echo ""
  
echo "======================================2、查询elasticsearch======================================"
echo "****************2.1查询elasticsearch集群状态****************"
result2_1=$(bash /opt/mscp-tools/shell/es_status.sh cluster)
echo "$result2_1"

echo "****************2.2查询elasticsearch索引状态****************"
result2_2=$(bash /opt/mscp-tools/shell/es_status.sh index)
echo "$result2_2"
echo ""
  
echo "======================================3、查询组件是否有响应======================================"
echo "*******************3.1查询uaa是否有响应*******************"
result3_1=$(bash /opt/mscp-tools/shell/token_get.sh uaa admin Rgsdn@66)
formatted_response=$(echo "$result3_1" | jq '.')
echo "$formatted_response"
echo ""

echo "***************3.2查询api-gateway是否有响应***************"
result3_2=$(bash /opt/mscp-tools/shell/token_get.sh gate admin Rgsdn@66)
formatted_response2=$(echo "$result3_2" | jq '.')
echo "$formatted_response2"
echo ""

echo "*****************3.3查询haproxy是否有响应*****************"
result3_3=$(bash /opt/mscp-tools/shell/token_get.sh haproxy admin Rgsdn@66)
formatted_response3=$(echo "$result3_3" | jq '.')
echo "$formatted_response3"
echo ""

echo "===========================4、查询redis确认集群状态、主节点、读写正常==========================="
redis_container=$(docker ps | grep redis- | awk '{print $1}')
if [ "$system_status" == "alone" ]
then
  
  echo "************4.1检查 Redis 增删改查功能是否正常************"
  #新增操作
  insert_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie SET key value)
  #查询操作
  query_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie GET key)
  #修改操作
  update_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie SET key value1)
  #删除操作
  delete_result=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 8379 -a redis_ruijie DEL key)
  
  # 输出结果
  echo ""
  echo "SET key value验证新增功能："
  echo "$insert_result"
  echo ""
  echo "GET key验证查询功能："
  echo "$query_result"
  echo ""
  echo "SET key value1验证修改功能："
  echo "$update_result"
  echo ""
  echo "DEL key验证删除功能："
  echo "$delete_result"
  echo ""
  
  

elif [ "$system_status" == "cluster" ]
then
  
  echo "********************4.1获取主节点信息********************"
  leader_info=$(docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 18379 -a redis_ruijie SENTINEL get-master-addr-by-name mscp_sentinel)
  leaders="$leader_info"
  ip=$(echo "$leaders" | head -n 1)
  port=$(echo "$leaders" | tail -n 1)
  echo "主节点：$ip"
  echo "端口：$port"
  
  echo "*********4.2连接到主节点检查 Redis 增删改查功能是否正常*********"
  #新增操作
  insert_result=$(docker exec "$redis_container" redis-cli -h $ip -p 8379 -a redis_ruijie SET key value)
  #查询操作
  query_result=$(docker exec "$redis_container" redis-cli -h $ip -p 8379 -a redis_ruijie GET key)
  #修改操作
  update_result=$(docker exec "$redis_container" redis-cli -h $ip -p 8379 -a redis_ruijie SET key value1)
  #删除操作
  delete_result=$(docker exec "$redis_container" redis-cli -h $ip -p 8379 -a redis_ruijie DEL key)
  # 输出结果
  echo ""
  echo "SET key value验证新增功能："
  echo "$insert_result"
  echo ""
  echo "GET key验证查询功能："
  echo "$query_result"
  echo ""
  echo "SET key value1验证修改功能："
  echo "$update_result"
  echo ""
  echo "DEL key验证删除功能："
  echo "$delete_result"
  
  
  echo "*********************4.3获取集群信息*********************"
  result4_3=$(bash /opt/mscp-tools/shell/redis_status.sh cluster)
  echo "$result4_3"
  echo ""
  
fi

echo "==============================5、查询postgres状态（覆盖zookeeper）=============================="
resutl5_1=$(bash /opt/mscp-tools/shell/query_postgre_cluster.sh)
echo "$resutl5_1"
echo ""

echo "======================================6、查询kafka健康状态======================================"
result6_1=$(bash /opt/mscp-tools/shell/kafka_health_check.sh)
echo "$result6_1"
echo ""

echo "==================================7、测试ping连集群中的其他节点=================================="
if [ "$system_status" == "alone" ]
then

  echo "单机环境不进行检查"

elif [ "$system_status" == "cluster" ]
then

  result7_1=$(bash /opt/mscp-tools/shell/ping_node.sh)
  echo "$result7_1"

fi

echo ""

echo "++++++++++++++++++++++++++++++++++*一键检查结果汇总：*++++++++++++++++++++++++++++++++++"
echo "1、查磁盘"
echo "1.1文件系统磁盘大小"
if [ -n "$resutl1_1" ]; then
  echo "查询成功，输出信息过多上拉查看详情"
  output1_1=true
else
  echo "查询失败"
  output1_1=false
  outinfo1_1="df -h命令执行结果为空"
fi
echo ""
echo "1.2查看/ibnsdata文件夹磁盘大小"
if [ -n "$resutl1_2" ]; then
  usage=$(echo "$resutl1_2" | awk '{print $1}')
  echo "查询成功，$usage"
  output1_2=true
else
  echo "查询失败"
  output1_2=false
  outinfo1_2="du -sh /ibnsdata命令执行结果为空"
fi
echo ""
echo "1.3查看/var/lib/docker文件夹磁盘大小"
if [ -n "$resutl1_3" ]; then
  usage=$(echo "$resutl1_3" | awk '{print $1}')
  echo "查询成功，$usage"
  output1_3=true
else
  echo "查询失败"
  output1_3=false
  outinfo1_3="du -sh /var/lib/docker命令执行结果为空"
fi
echo ""

echo "2、查询elasticsearch"
echo "2.1查询elasticsearch集群状态"
if [[ -n "$result2_1" && "$result2_1" != *"Connection refused"* ]]; then
  echo "查询成功"
  echo "$result2_1"
  output2_1=true
else
  echo "查询失败"
  output2_1=false
  outinfo2_1="curl -XGET 'http://127.0.0.1:9201/_cat/nodes?v' --header 'Authorization: Basic ZWxhc3RpYzpFbGFzdGljc2VhcmNoQHJ1aWppZQ=='请求结果为空"
fi
echo ""
echo "2.2查询elasticsearch索引状态"
if [[ -n "$result2_2" && "$result2_2" != *"Connection refused"* ]]; then
  echo "查询成功，输出信息过多上拉查看详情"
  #echo "$result2_2"
  output2_2=true
else
  echo "查询失败"
  output2_2=false
  outinfo2_2="curl -XGET 'http://127.0.0.1:9201/_cat/indices' --header 'Authorization: Basic ZWxhc3RpYzpFbGFzdGljc2VhcmNoQHJ1aWppZQ=='请求结果为空"
fi
echo ""

echo "3、查询组件获取token"
echo "3.1查询uaa是否有响应"
if [[ -n "$result3_1" && "$result3_1" != *"Connection refused"* ]]; then
  echo "查询成功，uaa有响应"
  output3_1=true
else
  echo "查询失败"
  output3_1=false
  outinfo3_1="Connection refused，curl -s --location --request POST 'http://127.0.0.1:9999/oauth/token' --header 'Content-Type: application/x-www-form-urlencoded' --header 'Authorization: Basic d2ViX2FwcDpyZ3Nkbg==' --data-urlencode 'grant_type=password' --data-urlencode 'username=admin' --data-urlencode 'password=Rgsdn@66'接口无响应"
fi
echo ""
echo "3.2查询api-gateway是否有响应"
if [[ -n "$result3_2" && "$result3_2" != *"Connection refused"* ]]; then
  echo "查询成功，api-gateway有响应"
  output3_2=true
else
  echo "查询失败"
  output3_2=false
  outinfo3_2="Connection refused，curl -s --location --request POST 'http://127.0.0.1:18181/oauth/token' --header 'Content-Type: application/x-www-form-urlencoded' --header 'Authorization: Basic d2ViX2FwcDpyZ3Nkbg==' --data-urlencode 'grant_type=password' --data-urlencode 'username=admin' --data-urlencode 'password=Rgsdn@66'接口无响应"
fi
echo ""
echo "3.3查询haproxy是否有响应"
if [[ -n "$result3_3" && "$result3_3" != *"Connection refused"* ]]; then
  echo "查询成功，haproxy有响应"
  output3_3=true
else
  echo "查询失败"
  output3_3=false
  outinfo3_3="Connection refused，curl -s --location --request POST 'http://127.0.0.1:18080/oauth/token' --header 'Content-Type: application/x-www-form-urlencoded' --header 'Authorization: Basic d2ViX2FwcDpyZ3Nkbg==' --data-urlencode 'grant_type=password' --data-urlencode 'username=admin' --data-urlencode 'password=Rgsdn@66'接口无响应"
fi
echo ""

echo "4、查询redis确认集群状态、主节点、读写正常"
if [ "$system_status" == "alone" ]
then

  if [[ "$insert_result" == "OK" && "$query_result" == "value" && "$update_result" == "OK" && "$delete_result" == "1" ]]; then
    echo "redis读写功能正常"
    output4_2=true
  else
    echo "redis读写功能异常"
    output4_2=false
    outinfo4_2="SET key value结果：$insert_result；GET key结果：$query_result；SET key value1结果：$update_result；DEL key结果：$delete_result；"
  fi

elif [ "$system_status" == "cluster" ]
then

  echo "4.1获取主节点信息"
  if [[ -n "$ip" && -n "$port" ]]; then
    echo "查询成功，主节点信息："
    echo "ip：$ip"
    echo "port：$port"
    output4_1=true
  else
    echo "查询失败"
    output4_1=false
    outinfo4_2="命令docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 18379 -a redis_ruijie SENTINEL get-master-addr-by-name mscp_sentinel输出为空，没有获得到主节点信息"
  fi
  echo ""
  
  echo "4.2连接到主节点检查 Redis 增删改查功能是否正常"
  if [[ "$insert_result" == "OK" && "$query_result" == "value" && "$update_result" == "OK" && "$delete_result" == "1" ]]; then
    echo "redis读写功能正常"
    output4_2=true
  else
    echo "redis读写功能异常"
    output4_2=false
    outinfo4_2="SET key value结果：$insert_result；GET key结果：$query_result；SET key value1结果：$update_result；DEL key结果：$delete_result；"
  fi
  echo ""
  
  echo "4.3获取集群信息"
  if [[ -n "$result4_3" && "$result4_3" != *"Connection refused"* ]]; then
    echo "查询成功，输出信息过多上拉查看详情"
    output4_3=true
  else
    echo "查询失败"
    output4_3=false
    outinfo4_3="命令docker exec "$redis_container" redis-cli -h 127.0.0.1 -p 18379 -a redis_ruijie SENTINEL masters输出为空，没有获得到主节点信息"
  fi
  echo ""

fi

echo "5、查询postgres状态（覆盖zookeeper）"
leader_info=$(echo "$resutl5_1" | grep Leader)
run_info=$(echo "$resutl5_1" | grep running | wc -l)
if [ "$system_status" == "alone" ]
then
  
  if [ -n "$leader_info" ] && [ "$run_info" == 1 ]; then
        
     echo "查询成功，postgres状态："
     echo "$resutl5_1"
     output5_1=true
        
  else
    
    if [ -z "$leader_info" ]; then
      echo "查询失败，没有找到postgres主节点："
      outinfo5_1="没有找到postgres主节点"
    else
      echo "查询失败，running节点$run_info个，不足1个："
      outinfo5_1="running节点$run_info个，不足1个"
    fi

    echo "$resutl5_1"
    output5_1=false
        
  fi

elif [ "$system_status" == "cluster" ]
then

  if [ -n "$leader_info" ] && [ "$run_info" == 3 ]; then
        
     echo "查询成功，postgres状态："
     echo "$resutl5_1"
     output5_1=true
        
  else
    
    if [ -z "$leader_info" ]; then
      echo "查询失败，没有找到postgres主节点："
      outinfo5_1="没有找到postgres主节点"
    else
      echo "查询失败，running节点$run_info个，不足3个："
      outinfo5_1="running节点$run_info个，不足3个"
    fi

    echo "$resutl5_1"
    output5_1=false
        
  fi

fi
echo "6、查询kafka健康状态"
if [[ -n "$result6_1" && "$result6_1" != *"Failed"* ]]; then
  echo "查询成功，kafka健康，创建、删除topic正常，发送、接收消息正常"
  output6_1=true
else
  echo "查询失败"
  output6_1=false
  
  if [[ "$result6_1" == *"Failed Kafka does not exist"* ]]; then
    
    outinfo6_1="连接kafka失败，容器内不存在Kafka"    
  
  else
  
    outinfo6_1="连接kafka失败，导致发送或接收消息失败"
  
  fi
  
fi
echo ""

echo "7、测试ping连集群中的其他节点"
if [ "$system_status" == "alone" ]
then

  echo "单机环境不进行检查"

elif [ "$system_status" == "cluster" ]
then

  if [[ -n "$result7_1" && "$result7_1" != *"failed"* ]]; then
    echo "$result7_1"
    output7_1=true
  else
    output7_1=false
    outinfo7_1="$result7_1"
  fi

fi
echo ""


echo_log=""
if [ "$output1_1" == true ]
then

  echo_log="$echo_log"

elif [ "$output1_1" == false ]
then

  echo_log="$echo_log查询文件系统磁盘大小异常；\n$outinfo1_1\n\n"

fi
if [ "$output1_2" == true ]
then

  echo_log="$echo_log"

elif [ "$output1_2" == false ]
then

  echo_log="$echo_log查看/ibnsdata文件夹磁盘大小异常；\n$outinfo1_2\n\n"

fi
if [ "$output1_3" == true ]
then

  echo_log="$echo_log"

elif [ "$output1_3" == false ]
then

  echo_log="$echo_log查看/var/lib/docker文件夹磁盘大小异常；\n$outinfo1_3\n\n"

fi
if [ "$output2_1" == true ]
then

  echo_log="$echo_log"

elif [ "$output2_1" == false ]
then

  echo_log="$echo_log查询elasticsearch集群状态异常；\n$outinfo2_1\n\n"

fi
if [ "$output2_2" == true ]
then

  echo_log="$echo_log"

elif [ "$output2_2" == false ]
then

  echo_log="$echo_log查询elasticsearch索引状态异常；\n$outinfo2_2\n\n"

fi
if [ "$output3_1" == true ]
then

  echo_log="$echo_log"

elif [ "$output3_1" == false ]
then

  echo_log="$echo_log组件uaa响应异常；\n$outinfo3_1\n\n"

fi
if [ "$output3_2" == true ]
then

  echo_log="$echo_log"

elif [ "$output3_2" == false ]
then

  echo_log="$echo_log组件api-gateway响应异常；\n$outinfo3_2\n\n"

fi
if [ "$output3_3" == true ]
then

  echo_log="$echo_log"

elif [ "$output3_3" == false ]
then

  echo_log="$echo_log组件haproxy响应异常；\n$outinfo3_3\n\n"

fi

if [ "$system_status" == "alone" ]
then
  
  if [ "$output4_2" == true ]
  then
  
    echo_log="$echo_log"
  
  elif [ "$output4_2" == false ]
  then
  
    echo_log="$echo_log组件redis读写功能异常；\n$outinfo4_2\n\n"
  
  fi

elif [ "$system_status" == "cluster" ]
then

  if [ "$output4_1" == true ]
  then
  
    echo_log="$echo_log"
  
  elif [ "$output4_1" == false ]
  then
  
    echo_log="$echo_log获取主节点信息异常；\n$outinfo4_1\n\n"
  
  fi

  if [ "$output4_2" == true ]
  then
  
    echo_log="$echo_log"
  
  elif [ "$output4_2" == false ]
  then
  
    echo_log="$echo_log组件redis读写功能异常；\n$outinfo4_2\n\n"
  
  fi
  
  if [ "$output4_3" == true ]
  then
  
    echo_log="$echo_log"
  
  elif [ "$output4_3" == false ]
  then
  
    echo_log="$echo_log获取集群信息异常；\n$outinfo4_3\n\n"
  
  fi

fi
if [ "$output5_1" == true ]
then

  echo_log="$echo_log"

elif [ "$output5_1" == false ]
then

  echo_log="$echo_log查询postgres状态（覆盖zookeeper）异常；\n$outinfo5_1\n\n"

fi

if [ "$output6_1" == true ]
then

  echo_log="$echo_log"

elif [ "$output6_1" == false ]
then

  echo_log="$echo_log组件kafka异常；\n$outinfo6_1\n\n"

fi

if [ "$system_status" == "cluster" ]
then

  if [ "$output7_1" == true ]
  then
  
    echo_log="$echo_log"
  
  elif [ "$output7_1" == false ]
  then
  
    echo_log="$echo_log访问集群其他节点异常；\n$outinfo7_1\n\n"
  
  fi

fi



#总结输出
if [ "$system_status" == "alone" ]
then
  
  if [ "$output1_1" == true ] && [ "$output1_2" == true ] && [ "$output1_3" == true ] && [ "$output2_1" == true ] && [ "$output2_2" == true ] && [ "$output3_1" == true ] && [ "$output3_2" == true ] && [ "$output3_3" == true ] && [ "$output4_2" == true ] && [ "$output5_1" == true ] && [ "$output6_1" == true ]
  then
  
    echo "*日志结束*"
    echo "success，检查系统健康完毕，磁盘、elasticsearch、uaa、api-gateway、haproxy、redis、postgres、kafka没有发现异常"
  
  else
    
    echo "*日志结束*"
    echo -e "failed，检查系统健康完毕，发现异常：\n$echo_log"
  
  fi

elif [ "$system_status" == "cluster" ]
then

    if [ "$output1_1" == true ] && [ "$output1_2" == true ] && [ "$output1_3" == true ] && [ "$output2_1" == true ] && [ "$output2_2" == true ] && [ "$output3_1" == true ] && [ "$output3_2" == true ] && [ "$output3_3" == true ] && [ "$output4_1" == true ] && [ "$output4_2" == true ] && [ "$output4_3" == true ] && [ "$output5_1" == true ] && [ "$output6_1" == true ] && [ "$output7_1" == true ]
  then
  
    echo "*日志结束*"
    echo "success，检查系统健康完毕，磁盘、elasticsearch、uaa、api-gateway、haproxy、redis、postgres、kafka、连通其他节点没有发现异常"
  
  else
    
    echo "*日志结束*"
    echo -e "failed，检查系统健康完毕，发现异常：\n$echo_log"
  
  fi

fi

