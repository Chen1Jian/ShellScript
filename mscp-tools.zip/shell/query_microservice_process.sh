#!/bin/bash
#查询微服务进程
if [[ "$(docker ps --format "{{.Names}}"|grep ${1,,} | wc -l)" <1  ]]; then
  echo $1"容器不存在,请确认名称是否正确"
elif  [[ "$(docker ps --format "{{.Names}}"|grep ${1,,} | wc -l)" >1  ]]; then
  echo "找到多个名称包含$1的容器，请补齐容器名称，列表如下："
 docker ps --format "{{.Names}}"|grep ${1,,}
else
  ps -ef | grep $(docker inspect `docker ps | grep ${1,,} | awk '{print $1}'` | grep Pid\" | awk '{print $2}' | awk -F, '{print $1}')
fi