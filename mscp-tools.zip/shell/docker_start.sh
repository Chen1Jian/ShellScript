#!/bin/bash
#启动docker
docker start $1