#!/bin/bash

# 使用 hostname 命令获取 IP 地址
current_ip=$(hostname -I | awk '{print $1}')

ip1=$(cat /etc/hosts | grep rgibns1 | awk '{print $1}')
ip2=$(cat /etc/hosts | grep rgibns2 | awk '{print $1}')
ip3=$(cat /etc/hosts | grep rgibns3 | awk '{print $1}')
#ip3="172.28.204.155"
ip1_stats=
ip2_stats=
ip3_stats=

ip1_info=
ip2_info=
ip3_info=


ping -c 1 $ip1 > /dev/null  # 对第一个 IP 地址进行 ping 测试，将输出重定向到 /dev/null
if [ $? -eq 0 ]; then
  ip1_stats=true
  ip1_info="$ip1 可以 ping 通"
else
  ip1_stats=false
  ip1_info="$ip1 无法 ping 通"
fi

ping -c 1 $ip2 > /dev/null  # 对第二个 IP 地址进行 ping 测试，将输出重定向到 /dev/null
if [ $? -eq 0 ]; then
  ip2_stats=true
  ip2_info="$ip2 可以 ping 通"
else
  ip2_stats=false
  ip2_info="$ip2 无法 ping 通"
fi

ping -c 1 $ip3 > /dev/null  # 对第三个 IP 地址进行 ping 测试，将输出重定向到 /dev/null
if [ $? -eq 0 ]; then

  ip3_stats=true
  ip3_info="$ip3 可以 ping 通"
  
else
  ip3_stats=false
  ip3_info="$ip3 无法 ping 通"
fi

if [ "$ip1_stats" == true ] && [ "$ip2_stats" == true ] && [ "$ip3_stats" == true ]
then
  echo "success，当前节点可ping通集群中另外两个节点"
else
  echo "failed，$ip1_info、$ip2_info、$ip3_info"
fi
