#!/bin/bash

log_dir="/opt/mscp-tools/msf_logs"  # 日志目录
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")  # 当前日期和时间的时间戳
log_file="$log_dir/$timestamp.log"  # 日志文件路径
# 创建日志目录（如果不存在）
mkdir -p "$log_dir"

# 执行脚本，并将输出重定向到指定文件
echo "$timestamp"
echo "开始检查系统健康，预计时间1-2分钟"
bash /opt/mscp-tools/shell/system_health.sh > "$log_file" 2>&1

# 查找包含指定行的行号
start_line=$(grep -n "*日志结束*" "$log_file" | cut -d ":" -f 1)
# 输出指定行以下的内容
tail -n +"$((start_line+1))" "$log_file"

echo "日志文件：$log_file"
