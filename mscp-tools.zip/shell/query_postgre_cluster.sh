#!/bin/bash
#查询postgreSQL集群状态
docker exec -i `docker ps | grep postgres_ | awk '{print $1}'` patronictl -c /home/postgres/patroni.yml list