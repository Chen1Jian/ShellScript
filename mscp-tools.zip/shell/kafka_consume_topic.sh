#!/bin/bash

# 步骤 1: 获取 Kafka 容器的 ID
container_id=$(docker ps | grep kafka | awk '{print $1}')

#1、向某个topic发送消息
if [ "$1" = "send" ]
then

  topic_name=$2
  echo "topic-->$topic_name，请输入要发送的消息："
  
  docker exec -i "$container_id" /bin/sh -c "sh \$KAFKA_HOME/bin/kafka-console-producer.sh --producer.config \$KAFKA_HOME/config/producer.properties --broker-list localhost:9093 --topic \"$topic_name\""

#2、接收某个topic消息
#2.1、从最新的接收
elif [ "$1" = "consume" ]
then

  topic_name=$2
  echo "topic-->$topic_name，开始从最新的接收此topic消息："
  
  docker exec -i "$container_id" /bin/sh -c "sh \$KAFKA_HOME/bin/kafka-console-consumer.sh --consumer.config \$KAFKA_HOME/config/consumer.properties --bootstrap-server localhost:9093 --topic \"$topic_name\""
  
#2.2、从头接收某个topic消息
elif [ "$1" = "consume-b" ]
then

  topic_name=$2
  echo "topic-->$topic_name，开始从头接收此topic消息："
  
  docker exec -i "$container_id" /bin/sh -c "sh \$KAFKA_HOME/bin/kafka-console-consumer.sh --consumer.config \$KAFKA_HOME/config/consumer.properties --bootstrap-server localhost:9093 --topic \"$topic_name\" --from-beginning"

#2.3、从尾部接收，指定partition接收
elif [ "$1" = "consume-l" ]
then

  topic_name=$2
  echo "topic-->$topic_name，从尾部接收，指定partition接收："
  
  docker exec -i "$container_id" /bin/sh -c "sh \$KAFKA_HOME/bin/kafka-console-consumer.sh --consumer.config \$KAFKA_HOME/config/consumer.properties --bootstrap-server localhost:9093 --topic \"$topic_name\" --offset latest  --partition 1"

#2.4、指定消费者组进行消费
elif [ "$1" = "consume-g" ]
then

  topic_name=$2
  group_name=$3
  
  echo "topic-->$topic_name，指定消费者组$group_name进行消费："
  
  docker exec -i "$container_id" /bin/sh -c "sh \$KAFKA_HOME/bin/kafka-console-consumer.sh --consumer.config \$KAFKA_HOME/config/consumer.properties --bootstrap-server localhost:9093 --topic \"$topic_name\" --consumer-property  --group \"$group_name\" --from-beginning"

fi