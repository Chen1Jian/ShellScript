#!/bin/bash
#重启防火墙
service firewalld restart