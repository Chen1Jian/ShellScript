#!/bin/bash


#查看/ibnsdata目录占用的磁盘大小
if [ "$1" = "ibns" ]
then

  dir_size=$(du -sh /ibnsdata)
  echo "$dir_size"
  
  
#查看/var/lib/docker目录占用的磁盘大小
elif [ "$1" = "docker" ]
then

  dir_size=$(du -sh /var/lib/docker)
  echo "$dir_size"
  
  
#查看文件系统的磁盘占用命令
elif [ "$1" = "system" ]
then

  dir_size=$(df -h)
  echo "$dir_size"
  
#查看其它文件夹占用的磁盘大小，输入绝对路径
else
  
  dir_size=$(du -sh "$1")
  echo "$dir_size"
  
fi