#!/bin/bash
#创建测试用数据库
image_id=$(docker ps | grep postgres_ | awk '{print $1}')
docker exec -e PGPASSWORD=rJ1#sDn@ -i $image_id  psql mscp_uaa --username "postgresadmin" -h 127.0.0.1 -p 25432 -tAc "update users set jhi_password = '\$2a\$10\$GzmK1NF5H21WzKAPkWslk.jz2REKoOjW9gAkKy/MVI72SLrZTX6VO' where id = 1"